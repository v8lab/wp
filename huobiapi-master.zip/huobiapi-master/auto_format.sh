#!/bin/sh

goreturns -b -d -e -w client market main.go main_test.go

